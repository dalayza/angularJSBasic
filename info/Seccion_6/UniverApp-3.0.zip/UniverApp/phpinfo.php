<?php

	phpinfo();

?>